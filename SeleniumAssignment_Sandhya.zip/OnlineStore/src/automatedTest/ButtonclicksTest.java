package automatedTest;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

 

public class ButtonclicksTest {

 

   public static void main(String[] args) throws Exception {

 
	   System.setProperty("webdriver.gecko.driver", "D:\\Sandhya_programs\\geckodriver-v0.27.0-win64\\geckodriver.exe");
      // Launch browser

      WebDriver driver = new FirefoxDriver();

 

      // Maximize window

      driver.manage().window().maximize();
      // Instantiate Actions
      Actions actions = new Actions(driver);     
 

      // Navigate to the URL

      driver.get("https://demoqa.com/buttons");

       // Sleep for 2 seconds

      Thread.sleep(2000);

 

       
      // Double click button
      WebElement element = driver.findElement(By.xpath("//*[@id=\"doubleClickBtn\"]"));
      actions.doubleClick(element).perform();
      // Right click button
      element = driver.findElement(By.xpath("//*[@id=\"rightClickBtn\"]"));
      actions.contextClick(element).perform();
      //Click dynamic button
    //Find the dynamicly created ID    
      driver.findElement(By.xpath("//button[starts-with(@text, �wsKxP�)]")).click();
      
   }
   

}

