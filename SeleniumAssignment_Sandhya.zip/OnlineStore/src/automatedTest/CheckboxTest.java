package automatedTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver; 

public class CheckboxTest {

 

   public static void main(String[] args) throws Exception {

 
	   System.setProperty("webdriver.gecko.driver", "D:\\Sandhya_programs\\geckodriver-v0.27.0-win64\\geckodriver.exe");
      // Launch browser

      WebDriver driver = new FirefoxDriver();

 

      // Maximize window

      driver.manage().window().maximize();

 

      // Navigate to the URL

      driver.get("https://demoqa.com/checkbox");

       // Sleep for 2 seconds

      Thread.sleep(2000);

 

      // Expand the tree element

      WebElement element = driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div[2]/div[1]/div/div/button[1]"));
      element.click();
      
      // Select all checkboxes
      driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div[2]/div[1]/div/ol/li/span/label/span[1]")).click();
      //Wait for 2 sec
      Thread.sleep(2000);
      // Deselect all checkboxes
      driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div[2]/div[1]/div/ol/li/span/label/span[1]")).click();
      //Wait for 2 sec
      Thread.sleep(2000);
      // Select few checkboxes
      driver.findElement(By.xpath("//*[@id=\"tree-node\"]/ol/li/ol/li[2]/span/label")).click();
      Thread.sleep(2000);
      // Deselect few checkboxes
      driver.findElement(By.xpath("//*[@id=\"tree-node\"]/ol/li/ol/li[2]/span/label")).click();
       
   
   }
   

}

