package automatedTest;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.NoAlertPresentException;


public class StudentRegTest {
	
	
	public static void main(String[] args) throws NoAlertPresentException,InterruptedException  {
		
		System.setProperty("webdriver.gecko.driver", "D:\\Sandhya_programs\\geckodriver-v0.27.0-win64\\geckodriver.exe");


		FirefoxDriver driver = new FirefoxDriver();
		driver.get("https://demoqa.com/automation-practice-form");			
                            		
     	//Enter first name   	
        driver.findElement(By.xpath("//*[@id=\"firstName\"]")).sendKeys("Sandhya");
        //Enter Last name
        driver.findElement(By.xpath("//*[@id=\"lastName\"]")).sendKeys("Rani");	
        //Enter email id
        driver.findElement(By.xpath("//*[@id=\"userEmail\"]")).sendKeys("sand@virtusa.com");
        //Select Gender      
        driver.findElement(By.xpath("//*[@id=\"genterWrapper\"]/div[2]/div[2]/label")).click();
        //Enter phone number      
        driver.findElement(By.xpath("//*[@id=\"userNumber\"]")).sendKeys("8192837488");
        //Enter date of birth        
        
        WebElement dtpick=driver.findElement(By.id("dateOfBirthInput"));
        dtpick.click();
        dtpick.findElement(By.xpath("//*[@id=\"dateOfBirth\"]/div[2]/div[2]/div/div/div[2]/div[1]/div[2]/div[1]/select/option[3]")).click();
        dtpick.findElement(By.xpath("//*[@id=\"dateOfBirth\"]/div[2]/div[2]/div/div/div[2]/div[1]/div[2]/div[2]/select/option[81]")).click();
        dtpick.findElement(By.xpath("//*[@id=\"dateOfBirth\"]/div[2]/div[2]/div/div/div[2]/div[2]/div[3]/div[2]")).click();
        
        //Enter subjects      
        WebElement select = driver.findElement(By.id("subjectsInput"));
        select.sendKeys("Maths");
        select.sendKeys(Keys.ARROW_DOWN);
        select.sendKeys(Keys.ENTER);
        select.sendKeys("Chemistry");
        select.sendKeys(Keys.ARROW_DOWN);
        select.sendKeys(Keys.ENTER);
        //Select Hobbies
        driver.findElement(By.xpath("//label[@for='hobbies-checkbox-2']")).click();
        driver.findElement(By.xpath("//label[@for='hobbies-checkbox-3']")).click();
        //Scroll down
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(500);
        
        //Select a picture
        WebElement pic=driver.findElement(By.id("uploadPicture"));
        pic.sendKeys(System.getProperty("user.dir")+"\\Sandhya.jpg");
        
   
        //Enter address
        driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[9]/div[2]/textarea")).sendKeys("Flat 308, Maa Brindavan");
 /*
        //Select state
        WebElement ste=driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div[2]/div[1]/form/div[10]/div[2]/div/div/div[2]/div/svg/path"));
        ste.click();
        //new Select(ste).selectByIndex(1);
        //new Select(driver.findElement(By.xpath("//*[@id=\"state\"]/div/div[1]"))).selectByVisibleText("NCR");
      //Select city
        WebElement cit=driver.findElement(By.id("city"));
        cit.click();
        cit.sendKeys(Keys.ARROW_DOWN);
        cit.sendKeys(Keys.ENTER);
 */
      //Submit data
        driver.findElement(By.id("submit")).click();
	}
	
        
        
	}

