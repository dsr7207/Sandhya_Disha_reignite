package automatedTest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

 

public class RadiobuttonTest {

 

   public static void main(String[] args) throws Exception {

 
	   System.setProperty("webdriver.gecko.driver", "D:\\Sandhya_programs\\geckodriver-v0.27.0-win64\\geckodriver.exe");
      // Launch browser

      WebDriver driver = new FirefoxDriver();

 

      // Maximize window

      driver.manage().window().maximize();

 

      // Navigate to the URL

      driver.get("https://demoqa.com/radio-button");

       // Sleep for 2 seconds

      Thread.sleep(2000);

 

       
      // Select Yes radio button
      driver.findElement(By.xpath("//*[@id=\"app\"]/div/div/div[2]/div[2]/div[1]/div[2]/label")).click();
      //Select Impressie radio button and check whether Yes button gets unchecked    
      driver.findElement(By.xpath("//*[@id=\"app\"]/div/div/div[2]/div[2]/div[1]/div[3]/label")).click();
      
   }
   

}

