package automatedTest;

import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.NoAlertPresentException;	
import org.openqa.selenium.Alert;

public class AlertHandleTest {
	
	public static void main(String[] args) throws NoAlertPresentException,InterruptedException  {									
		System.setProperty("webdriver.gecko.driver", "D:\\Sandhya_programs\\geckodriver-v0.27.0-win64\\geckodriver.exe");


		FirefoxDriver driver = new FirefoxDriver();

		driver.get("https://demoqa.com/alerts");			
                            		
     	//Generate alert by clicking the button      	
        driver.findElement(By.xpath("//*[@id=\"alertButton\"]")).click();						
        		
        // Switching to Alert        
        Alert alert = driver.switchTo().alert();		
        		
        // Capturing alert message.    
        String alertMessage= driver.switchTo().alert().getText();		
        		
        // Displaying alert message		
        System.out.println(alertMessage);	
        Thread.sleep(5000);
        		
        // Accepting alert		
        alert.accept();
        
      //Generate alert by clicking the button for dismissing alert      	
        driver.findElement(By.xpath("//*[@id=\"alertButton\"]")).click();						
        		
        // Switching to Alert        
        alert = driver.switchTo().alert();		
        		
        // Capturing alert message.    
        alertMessage= driver.switchTo().alert().getText();		
        		
        // Displaying alert message		
        System.out.println(alertMessage);	
        Thread.sleep(5000);
        		
        // Accepting alert		
        alert.dismiss();
      //Generate prompt for handling it
        driver.findElement(By.xpath("//*[@id=\"promtButton\"]")).click();
        alert = driver.switchTo().alert();
     // Displaying alert message		
        System.out.println(alertMessage);	
        Thread.sleep(5000);
        		
        // Accepting alert		
        alert.sendKeys("Test message!");;
        alert.accept();
    }	

}